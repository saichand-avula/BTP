import streamlit as st
import pandas as pd
import numpy as np
import pickle
from pathlib import Path

# --- Configuration ---
st.set_page_config(page_title="Clinical AI Auditor", layout="wide", page_icon="🏥")
BASE = Path(__file__).parent
MODELS_DIR = BASE / "models"

# --- Load Assets ---
@st.cache_resource
def load_system_assets():
    # Load ML Model & Features
    with open(MODELS_DIR / "layer1_model.pkl", 'rb') as f:
        model = pickle.load(f)
    with open(MODELS_DIR / "layer1_features.pkl", 'rb') as f:
        feature_names = pickle.load(f)
    with open(MODELS_DIR / "layer1_explainer.pkl", 'rb') as f:
        explainer = pickle.load(f)
    
    # Load Causal Audit Rulebook
    causal_rules = pd.DataFrame()
    if (MODELS_DIR / "layer2_causal_results.csv").exists():
        causal_rules = pd.read_csv(MODELS_DIR / "layer2_causal_results.csv")
        
    return model, feature_names, explainer, causal_rules

model, feature_names, explainer, causal_rules = load_system_assets()

# --- UI Header ---
st.title("🏥 Clinical Decision Support with Causal Auditing")
st.markdown("Enter patient details below to predict 30-day readmission risk and generate a causally-safe intervention plan.")
st.divider()

# --- Sidebar: Patient Input ---
st.sidebar.header("Patient Vitals & History")

# Changed from sliders to direct number inputs
time_in_hospital = st.sidebar.number_input("Time in Hospital (Days)", min_value=1, max_value=14, value=4, step=1)
num_lab_procedures = st.sidebar.number_input("Number of Lab Procedures", min_value=1, max_value=132, value=44, step=1)
num_medications = st.sidebar.number_input("Number of Medications", min_value=1, max_value=81, value=15, step=1)
num_procedures = st.sidebar.number_input("Number of Procedures", min_value=0, max_value=6, value=1, step=1)
number_inpatient = st.sidebar.number_input("Prior Inpatient Visits", min_value=0, max_value=21, value=0, step=1)
insulin_prescribed = st.sidebar.radio("Insulin Prescribed?", ["Yes", "No"])

# --- Prediction Logic ---
if st.sidebar.button("Predict & Audit Risk", type="primary"):
    
    # 1. Create a baseline patient row (zeros) matching the 139 features
    patient_row = np.zeros(len(feature_names))
    patient_dict = dict(zip(feature_names, patient_row))
    
    # 2. Update the row with the doctor's inputs
    if "time_in_hospital" in patient_dict: patient_dict["time_in_hospital"] = time_in_hospital
    if "num_lab_procedures" in patient_dict: patient_dict["num_lab_procedures"] = num_lab_procedures
    if "num_medications" in patient_dict: patient_dict["num_medications"] = num_medications
    if "num_procedures" in patient_dict: patient_dict["num_procedures"] = num_procedures
    if "number_inpatient" in patient_dict: patient_dict["number_inpatient"] = number_inpatient
    if "insulin_prescribed" in patient_dict: patient_dict["insulin_prescribed"] = 1.0 if insulin_prescribed == "Yes" else 0.0

    # Convert back to array for the model
    X_input = np.array(list(patient_dict.values())).reshape(1, -1)
    
    # 3. Predict!
    prob = model.predict_proba(X_input)[0, 1]
    
    # --- UI Layout: Results ---
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Risk Assessment")
        risk_color = "red" if prob > 0.5 else "green"
        st.markdown(f"<h1 style='color: {risk_color}; font-size: 4rem;'>{prob*100:.1f}%</h1>", unsafe_allow_html=True)
        st.write("**Prediction:**", "HIGH RISK (Readmission)" if prob > 0.5 else "LOW RISK")
        
    with col2:
        st.subheader("Causally Audited Explanations")
        
        # 4. Get SHAP values
        shap_vals = explainer.shap_values(X_input)
        if isinstance(shap_vals, list): shap_vals = shap_vals[1]
        shap_vals = shap_vals.flatten()
        
        # Match SHAP values to features and sort by magnitude
        importance_df = pd.DataFrame({'Feature': feature_names, 'SHAP': shap_vals})
        importance_df['Abs_SHAP'] = importance_df['SHAP'].abs()
        top_factors = importance_df.nlargest(5, 'Abs_SHAP')
        
        # 5. The Magic: Intercept with Causal Rules
        for _, row in top_factors.iterrows():
            feature = row['Feature']
            shap_impact = row['SHAP']
            direction = "increases" if shap_impact > 0 else "decreases"
            
            # Look up the feature in our Causal CSV
            audit_record = causal_rules[causal_rules['Feature'] == feature]
            
            with st.expander(f"Factor: {feature} ({direction} risk)"):
                # Fixed text to accurately reflect SHAP log-odds scores instead of raw percentages
                st.write(f"Standard AI says this feature **{direction}** the risk with a SHAP impact score of **{abs(shap_impact):.2f}**.")
                
                # Apply the safety filter
                if not audit_record.empty:
                    status = audit_record['Status'].values[0]
                    e_value = audit_record['E_Value'].values[0]
                    
                    if status == "FRAGILE":
                        st.error(f"🚨 **CLINICAL OVERRIDE:** The Causal Audit flagged this feature as **FRAGILE (E-Value: {e_value})**. This is a confounded proxy for disease severity. **DO NOT** alter this treatment to lower the risk score.")
                    elif status == "ROBUST":
                        st.success(f"✅ **SAFE INTERVENTION:** This feature is causally **ROBUST (E-Value: {e_value})**. Modifying this is statistically safe and recommended.")
                    elif status == "PROTECTED":
                        st.warning("⚠️ **IMMUTABLE:** This is a demographic attribute. Excluded for fairness.")
                else:
                    st.info("ℹ️ No causal audit data available for this specific feature.")