#!/usr/bin/env python3
"""
Layer 2 - Counterfactual Explanations
  - Reads the Causal Audit Results (Layer 3)
  - STRICT FILTER: Only allows interventions on features marked 'ROBUST'
  - Generates counterfactuals for HIGH RISK patients
"""

import pickle
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
import os

warnings.filterwarnings('ignore')

BASE         = Path(__file__).parent
CLEANED_DATA = BASE / "data_processed" / "diabetic_data_cleaned.csv"
MODELS_DIR   = BASE / "models"

MODEL_PKL    = MODELS_DIR / "layer1_model.pkl"
FEATURES_PKL = MODELS_DIR / "layer1_features.pkl"
CAUSAL_CSV   = MODELS_DIR / "layer2_causal_results.csv"

def get_robust_features():
    """Reads the causal audit results and returns ONLY features marked as ROBUST."""
    if not CAUSAL_CSV.exists():
        print("  [!] No causal audit results found. Run causal audit first.")
        return []
    
    causal_df = pd.read_csv(CAUSAL_CSV)
    # Architecture Rule: Only ROBUST features are mutable
    robust_features = causal_df[causal_df['Status'] == 'ROBUST']['Feature'].tolist()
    return robust_features

def _load_model():
    with open(MODEL_PKL, 'rb') as f:
        model = pickle.load(f)
    with open(FEATURES_PKL, 'rb') as f:
        features = pickle.load(f)
    return model, features

def greedy_counterfactual(model, patient_row, feature_names, df_ref, robust_features, max_changes=5):
    """
    Greedy search: find the minimal set of strictly ROBUST feature changes
    that flips the prediction.
    """
    x = patient_row.copy()
    
    # Strictly filter actionable indices to only ROBUST features
    actionable_idx = [
        i for i, f in enumerate(feature_names)
        if any(f.startswith(r) for r in robust_features)
    ]

    # If no features are causally robust, we cannot safely generate a counterfactual
    if not actionable_idx:
        return {
            "flipped": 0,
            "new_probability": float(model.predict_proba(x.reshape(1, -1))[0, 1]),
            "num_changes": 0,
            "changes": {},
            "counterfactual_row": x,
        }

    changes = {}

    for idx in actionable_idx[:max_changes * 3]:
        feat     = feature_names[idx]
        orig_val = x[idx]

        col_vals = df_ref[feat].dropna().unique()
        col_vals = sorted(col_vals)

        best_val  = orig_val
        best_prob = model.predict_proba(x.reshape(1, -1))[0, 1]

        for candidate in col_vals:
            if candidate == orig_val:
                continue
            x_try = x.copy()
            x_try[idx] = candidate
            prob = model.predict_proba(x_try.reshape(1, -1))[0, 1]
            if prob < best_prob:
                best_prob = prob
                best_val  = candidate

        if best_val != orig_val:
            x[idx] = best_val
            changes[feat] = {"original": orig_val, "counterfactual": best_val}

        new_pred = model.predict(x.reshape(1, -1))[0]
        if new_pred == 0:
            break

    new_pred  = model.predict(x.reshape(1, -1))[0]
    new_prob  = model.predict_proba(x.reshape(1, -1))[0, 1]

    return {
        "flipped":           int(new_pred == 0),
        "new_probability":   float(new_prob),
        "num_changes":       len(changes),
        "changes":           changes,
        "counterfactual_row": x,
    }

def run(n_patients=20):
    print("\n" + "=" * 55)
    print("LAYER 3: SAFE CLINICAL RECOMMENDATIONS")
    print("=" * 55)

    df = pd.read_csv(CLEANED_DATA)
    model, feature_names = _load_model()
    
    # Fetch safe features from the Causal Audit
    robust_features = get_robust_features()
    print(f"Loaded {len(robust_features)} ROBUST features for safe recourse.")
    
    X = df[feature_names].values
    y = df['Readmitted_30d'].values

    y_pred = model.predict(X)
    y_prob = model.predict_proba(X)[:, 1]

    high_risk_idx = np.where((y_pred == 1) & (y == 1))[0]
    if len(high_risk_idx) == 0:
        high_risk_idx = np.where(y_pred == 1)[0]

    sample_idx = np.random.choice(high_risk_idx, size=min(n_patients, len(high_risk_idx)), replace=False)

    records = []
    flip_count = 0

    print(f"\nGenerating counterfactuals for {len(sample_idx)} high-risk patients...\n")
    print(f"  {'Patient':<10} {'Original P(readmit)':<22} {'CF P(readmit)':<18} {'Changes':<10} {'Flipped?'}")
    print("  " + "-" * 72)

    for i, idx in enumerate(sample_idx):
        orig_prob = float(y_prob[idx])
        cf = greedy_counterfactual(model, X[idx], feature_names, df, robust_features)

        flipped = cf["flipped"]
        flip_count += cf["flipped"]

        print(
            f"  {idx:<10} {orig_prob:<22.4f} {cf['new_probability']:<18.4f} "
            f"{cf['num_changes']:<10} {'✓' if flipped else '✗'}"
        )

        for feat, vals in cf["changes"].items():
            print(f"             ↳ {feat}: {vals['original']} → {vals['counterfactual']}")

        records.append({
            "patient_idx":    int(idx),
            "original_prob":  orig_prob,
            "cf_prob":        cf["new_probability"],
            "flipped":        flipped,
            "num_changes":    cf["num_changes"],
            "changes_str":    str(cf["changes"]),
        })

    print(f"\nFlip rate: {flip_count}/{len(sample_idx)} patients flipped ({flip_count/len(sample_idx)*100:.0f}%)")
    
    if flip_count == 0:
        print("\n⚠ CRITICAL FINDING: 0% Flip Rate.")
        print("Because all major ML features were flagged as FRAGILE/CONFOUNDED by the Causal Audit,")
        print("the system successfully blocked all dangerous recommendations. No safe interventions exist.")

    out_df   = pd.DataFrame(records)
    out_path = MODELS_DIR / "layer3_counterfactuals.csv"
    out_df.to_csv(out_path, index=False)
    print(f"\nCounterfactuals saved → {out_path}")

    return out_df

if __name__ == "__main__":
    run(n_patients=20)